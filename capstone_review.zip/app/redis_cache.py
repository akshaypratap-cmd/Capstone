import json
import logging

import redis

from app.config import settings


logger = logging.getLogger(__name__)


# Connect to Redis
try:

    redis_client = redis.Redis.from_url(
        settings.REDIS_URL,
        decode_responses=True,
        socket_connect_timeout=1
    )

    redis_client.ping()

    logger.info("Redis connected successfully")

except redis.RedisError:

    redis_client = None

    logger.warning("Redis is unavailable. Running without cache.")


# Get cached data
def get_cache(key: str):

    if redis_client is None:
        return None

    try:

        data = redis_client.get(key)

        if data is None:
            return None

        return json.loads(data)

    except redis.RedisError:

        logger.exception("Redis cache read failed")

        return None


# Save data in cache
def set_cache(key: str, data, expire: int = 60):

    if redis_client is None:
        return

    try:

        redis_client.setex(
            key,
            expire,
            json.dumps(data)
        )

    except redis.RedisError:

        logger.exception("Redis cache write failed")


# Delete cached data
def delete_cache(key: str):

    if redis_client is None:
        return

    try:

        redis_client.delete(key)

    except redis.RedisError:

        logger.exception("Redis cache deletion failed")