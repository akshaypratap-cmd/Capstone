from datetime import datetime, timedelta, timezone

import jwt

from pwdlib import PasswordHash

from app.config import settings


password_hash = PasswordHash.recommended()


# Hash password before saving
def hash_password(password: str):

    return password_hash.hash(password)


# Verify entered password
def verify_password(plain_password: str, hashed_password: str):

    return password_hash.verify(plain_password, hashed_password)


# Generate JWT access token
def create_access_token(user_id: int):

    expire = datetime.now(timezone.utc) + timedelta(
        minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )

    payload = {
        "sub": str(user_id),
        "exp": expire
    }

    token = jwt.encode(
        payload,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM
    )

    return token


# Verify JWT token
def verify_access_token(token: str):

    try:

        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )

        user_id = payload.get("sub")

        if user_id is None:
            return None

        return int(user_id)

    except (jwt.InvalidTokenError, ValueError, TypeError):

        return None