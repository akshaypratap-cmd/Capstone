import logging

from fastapi import FastAPI, Request

from fastapi.responses import JSONResponse


logger = logging.getLogger(__name__)


def register_error_handlers(app: FastAPI):

    @app.exception_handler(Exception)
    async def global_exception_handler(
        request: Request,
        exc: Exception
    ):

        logger.exception(
            "Unexpected error on %s",
            request.url.path
        )

        return JSONResponse(
            status_code=500,
            content={
                "detail": "Internal server error"
            }
        )