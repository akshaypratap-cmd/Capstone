import pytest

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from fastapi.testclient import TestClient

from app.database import Base
from app.dependencies import get_db

from main import app


# Separate database for testing
TEST_DATABASE_URL = "sqlite://"

test_engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool
)

TestingSessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=test_engine
)


# Create test database
@pytest.fixture
def db():

    Base.metadata.create_all(bind=test_engine)

    database = TestingSessionLocal()

    try:
        yield database

    finally:
        database.close()
        Base.metadata.drop_all(bind=test_engine)


# Override real database dependency
@pytest.fixture
def client(db):

    def override_get_db():

        yield db

    app.dependency_overrides[get_db] = override_get_db

    with TestClient(app) as test_client:

        yield test_client

    app.dependency_overrides.clear()


# Register a test user and return authentication headers
@pytest.fixture
def auth_headers(client):

    client.post(
        "/auth/register",
        json={
            "email": "test@example.com",
            "password": "password123"
        }
    )

    response = client.post(
        "/auth/login",
        data={
            "username": "test@example.com",
            "password": "password123"
        }
    )

    token = response.json()["access_token"]

    return {
        "Authorization": f"Bearer {token}"
    }